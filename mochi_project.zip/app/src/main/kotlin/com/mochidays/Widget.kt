package com.mochidays

import android.content.Context
import android.content.Intent
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.Image
import androidx.glance.ImageProvider
import androidx.glance.action.ActionParameters
import androidx.glance.action.actionParametersOf
import androidx.glance.action.clickable
import androidx.glance.appwidget.CheckBox
import androidx.glance.appwidget.CheckboxDefaults
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import androidx.glance.appwidget.action.ActionCallback
import androidx.glance.appwidget.action.actionRunCallback
import androidx.glance.appwidget.cornerRadius
import androidx.glance.appwidget.provideContent
import androidx.glance.appwidget.updateAll
import androidx.glance.background
import androidx.glance.layout.Alignment
import androidx.glance.layout.Column
import androidx.glance.layout.Row
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxHeight
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.height
import androidx.glance.layout.padding
import androidx.glance.layout.size
import androidx.glance.layout.width
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import kotlinx.coroutines.delay
import java.time.LocalTime

private val IdKey = ActionParameters.Key<Long>("task_id")
private val INK = Color(0xFF1D3557)
private val SUB = Color(0xFF6B84A3)
private val BLUE = Color(0xFF3B9BF5)

class TasksWidget : GlanceAppWidget() {
    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val tasks = Store.load(context)
        val pose = poseFor(context, tasks)
        provideContent { WidgetContent(tasks, pose) }
    }
}

class TasksWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = TasksWidget()
}

private fun poseFor(ctx: Context, tasks: List<Task>): Int {
    val sp = ctx.getSharedPreferences("mochi_days", Context.MODE_PRIVATE)
    if (System.currentTimeMillis() < sp.getLong("poke_until", 0L)) return R.drawable.mochi_cheer
    val open = tasks.filter { !it.done }
    if (tasks.isNotEmpty() && open.isEmpty()) return R.drawable.mochi_cheer
    val h = LocalTime.now().hour
    if (h >= 22 || h < 6) return R.drawable.mochi_sleep
    return when (open.firstOrNull()?.cat) {
        Cat.DRINK -> R.drawable.mochi_drink
        Cat.READ -> R.drawable.mochi_read
        Cat.EAT -> R.drawable.mochi_eat
        Cat.SLEEP -> R.drawable.mochi_sleep
        else -> R.drawable.mochi_idle
    }
}

@Composable
private fun WidgetContent(tasks: List<Task>, pose: Int) {
    val done = tasks.count { it.done }
    Row(
        GlanceModifier.fillMaxSize().background(Color(0xFFF1F8FF)).cornerRadius(26.dp).padding(14.dp)
    ) {
        Column(GlanceModifier.defaultWeight().fillMaxHeight()) {
            Text("Mochi Days", style = TextStyle(fontSize = 16.sp, fontWeight = FontWeight.Bold, color = ColorProvider(INK)),
                modifier = GlanceModifier.clickable(actionRunCallback<OpenAppAction>()))
            Text("$done of ${tasks.size} done", style = TextStyle(fontSize = 12.sp, color = ColorProvider(SUB)))
            Spacer(GlanceModifier.height(8.dp))
            if (tasks.isEmpty()) {
                Text("Open the app to add habits", style = TextStyle(fontSize = 13.sp, color = ColorProvider(SUB)))
            }
            tasks.take(5).forEach { t ->
                CheckBox(
                    checked = t.done,
                    onCheckedChange = actionRunCallback<ToggleAction>(actionParametersOf(IdKey to t.id)),
                    text = t.title,
                    style = TextStyle(fontSize = 14.sp, color = ColorProvider(if (t.done) SUB else INK)),
                    colors = CheckboxDefaults.colors(checkedColor = BLUE, uncheckedColor = SUB)
                )
            }
        }
        Spacer(GlanceModifier.width(8.dp))
        Column(GlanceModifier.fillMaxHeight(), verticalAlignment = Alignment.Bottom) {
            Image(
                provider = ImageProvider(pose), contentDescription = "Mochi",
                modifier = GlanceModifier.size(112.dp).clickable(actionRunCallback<PokeAction>())
            )
        }
    }
}

class ToggleAction : ActionCallback {
    override suspend fun onAction(context: Context, glanceId: GlanceId, parameters: ActionParameters) {
        val id = parameters[IdKey] ?: return
        Store.toggle(context, id)
        TasksWidget().updateAll(context)
    }
}

/** Tap Mochi on the home screen and he cheers for a moment. */
class PokeAction : ActionCallback {
    override suspend fun onAction(context: Context, glanceId: GlanceId, parameters: ActionParameters) {
        val sp = context.getSharedPreferences("mochi_days", Context.MODE_PRIVATE)
        sp.edit().putLong("poke_until", System.currentTimeMillis() + 2200L).apply()
        TasksWidget().updateAll(context)
        delay(2300L)
        TasksWidget().updateAll(context)
    }
}

class OpenAppAction : ActionCallback {
    override suspend fun onAction(context: Context, glanceId: GlanceId, parameters: ActionParameters) {
        context.startActivity(Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}
