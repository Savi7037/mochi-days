package com.mochidays

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import kotlin.math.PI
import kotlin.math.sin
import kotlin.random.Random

enum class PType { CONFETTI, HEART, SPARKLE, DROP, BUBBLE, ZZZ, NOTE, CRUMB }

class Particle(
    var x: Float, var y: Float, var vx: Float, var vy: Float,
    val life: Float, val type: PType, val color: Color, val size: Float, val gravity: Float = 0f
) {
    var age = 0f
    var rot = Random.nextFloat() * 360f
    var vr = (Random.nextFloat() - 0.5f) * 500f
}

/** Small particle system for the motion graphics (confetti, hearts, bubbles...). */
object Fx {
    private val list = ArrayList<Particle>()
    private val confettiColors = listOf(
        Color(0xFF5EAEFF), Color(0xFFFFB86B), Color(0xFF7ED6C1), Color(0xFFFF8FA3), Color(0xFFB39DFF), Color(0xFFFFD84D)
    )
    var density = 1f

    fun confetti(x: Float, y: Float, n: Int = 40) {
        repeat(n) {
            val a = Random.nextFloat() * 2f * PI.toFloat()
            val sp = (250f + Random.nextFloat() * 650f) * density
            list.add(Particle(x, y, kotlin.math.cos(a) * sp, kotlin.math.sin(a) * sp - 500f * density,
                1.8f + Random.nextFloat(), PType.CONFETTI, confettiColors.random(), (6f + Random.nextFloat() * 6f) * density, 1500f * density))
        }
    }
    fun hearts(x: Float, y: Float, n: Int = 3) = repeat(n) {
        list.add(Particle(x + (Random.nextFloat() - 0.5f) * 50f * density, y, (Random.nextFloat() - 0.5f) * 60f * density, -110f * density,
            1.4f, PType.HEART, Color(0xFFFF6F91), (9f + Random.nextFloat() * 6f) * density))
    }
    fun sparkle(x: Float, y: Float) = list.add(Particle(x, y, (Random.nextFloat() - 0.5f) * 40f * density, -40f * density,
        1.2f, PType.SPARKLE, Color(0xFFFFD84D), (8f + Random.nextFloat() * 6f) * density))
    fun drop(x: Float, y: Float, c: Color = Color(0xFF60B8FF), up: Float = 160f) = list.add(Particle(x, y, (Random.nextFloat() - 0.5f) * 120f * density,
        -up * density, 0.8f, PType.DROP, c, 5f * density, 700f * density))
    fun crumb(x: Float, y: Float) = list.add(Particle(x, y, (Random.nextFloat() - 0.5f) * 140f * density, -60f * density,
        0.7f, PType.CRUMB, Color(0xFFF0565C), 4f * density, 800f * density))
    fun bubble(x: Float, y: Float) = list.add(Particle(x, y, (Random.nextFloat() - 0.5f) * 40f * density, -70f * density,
        1.6f, PType.BUBBLE, Color(0xFF9BD3FF), (7f + Random.nextFloat() * 8f) * density))
    fun zzz(x: Float, y: Float) = list.add(Particle(x, y, 28f * density, -42f * density, 2.2f, PType.ZZZ, Color(0xFF7C8CE0), 10f * density))
    fun note(x: Float, y: Float) = list.add(Particle(x, y, (Random.nextFloat() - 0.5f) * 90f * density, -90f * density,
        1.5f, PType.NOTE, Color(0xFF7B6CF0), 9f * density))

    fun update(dt: Float) {
        val it = list.iterator()
        while (it.hasNext()) {
            val p = it.next()
            p.age += dt
            if (p.age >= p.life) { it.remove(); continue }
            p.vy += p.gravity * dt
            p.x += p.vx * dt; p.y += p.vy * dt; p.rot += p.vr * dt
        }
    }

    fun draw(d: DrawScope) {
        for (p in list) {
            val k = 1f - p.age / p.life
            val a = (if (p.type == PType.CONFETTI) k.coerceAtMost(0.6f) / 0.6f else k.coerceAtMost(0.5f) / 0.5f).coerceIn(0f, 1f)
            val c = p.color.copy(alpha = a)
            val s = p.size
            when (p.type) {
                PType.CONFETTI -> with(d) {
                    withTransform({ translate(p.x, p.y); rotate(p.rot, Offset.Zero) }) { drawRect(c, Offset(-s, -s / 2f), Size(s * 2f, s)) }
                }
                PType.HEART -> with(d) {
                    val path = Path().apply {
                        moveTo(0f, s * 0.35f)
                        cubicTo(-s, -s * 0.3f, -s * 0.4f, -s, 0f, -s * 0.35f)
                        cubicTo(s * 0.4f, -s, s, -s * 0.3f, 0f, s * 0.35f); close()
                    }
                    withTransform({ translate(p.x, p.y) }) { drawPath(path, c) }
                }
                PType.SPARKLE -> with(d) {
                    val path = Path().apply {
                        moveTo(0f, -s); quadraticBezierTo(s * 0.15f, -s * 0.15f, s, 0f)
                        quadraticBezierTo(s * 0.15f, s * 0.15f, 0f, s); quadraticBezierTo(-s * 0.15f, s * 0.15f, -s, 0f)
                        quadraticBezierTo(-s * 0.15f, -s * 0.15f, 0f, -s); close()
                    }
                    withTransform({ translate(p.x, p.y); rotate(p.rot * 0.2f, Offset.Zero) }) { drawPath(path, c) }
                }
                PType.DROP, PType.CRUMB -> with(d) { drawCircle(c, s, Offset(p.x, p.y)) }
                PType.BUBBLE -> with(d) {
                    val wob = sin(p.age * 6f) * 6f * density
                    drawCircle(c, s, Offset(p.x + wob, p.y), style = Stroke(2.2f * density))
                    drawCircle(c.copy(alpha = a * 0.25f), s * 0.8f, Offset(p.x + wob, p.y))
                }
                PType.ZZZ -> with(d) {
                    val grow = 0.8f + p.age * 0.35f
                    val z = s * grow
                    val path = Path().apply { moveTo(-z, -z); lineTo(z, -z); lineTo(-z, z); lineTo(z, z) }
                    withTransform({ translate(p.x, p.y) }) { drawPath(path, c, style = Stroke(2.6f * density, cap = StrokeCap.Round)) }
                }
                PType.NOTE -> with(d) {
                    drawCircle(c, s * 0.55f, Offset(p.x, p.y))
                    drawLine(c, Offset(p.x + s * 0.5f, p.y), Offset(p.x + s * 0.5f, p.y - s * 1.6f), 2.4f * density)
                    drawLine(c, Offset(p.x + s * 0.5f, p.y - s * 1.6f), Offset(p.x + s * 1.2f, p.y - s * 1.2f), 2.4f * density)
                }
            }
        }
    }
}
