package com.mochidays

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate

enum class Cat(val label: String) {
    DRINK("Hydrate"), EAT("Meal"), READ("Read"), MOVE("Move"),
    SLEEP("Rest"), CALM("Calm"), CLEAN("Self-care"), GENERAL("Task")
}

/** Mochi reads the words of a task and picks what to act out. */
object Detect {
    private val rules = listOf(
        Cat.DRINK to listOf("water", "drink", "hydrat", "tea", "juice", "coffee", "smoothie"),
        Cat.EAT to listOf("eat", "breakfast", "lunch", "dinner", "meal", "snack", "fruit", "veg", "cook", "food", "salad"),
        Cat.READ to listOf("read", "book", "study", "learn", "homework", "course", "lesson", "journal", "write"),
        Cat.MOVE to listOf("run", "jog", "workout", "gym", "exercise", "walk", "yoga", "stretch", "squat", "cycle", "bike", "swim", "sport", "dance", "push-up", "pushup"),
        Cat.SLEEP to listOf("sleep", "nap", "bed", "rest", "wake"),
        Cat.CALM to listOf("meditat", "breath", "calm", "relax", "mindful", "pray", "gratitude"),
        Cat.CLEAN to listOf("brush", "teeth", "shower", "wash", "skincare", "floss", "clean", "shave", "bath")
    )

    fun detect(title: String): Cat {
        val s = title.lowercase()
        for ((cat, words) in rules) if (words.any { s.contains(it) }) return cat
        return Cat.GENERAL
    }
}

data class Task(val id: Long, val title: String, val cat: Cat, val lastDone: String) {
    val done: Boolean get() = lastDone == Store.today()
}

/** Tiny local storage. Habits repeat daily: a task counts as done only if it was ticked today. */
object Store {
    private const val PREF = "mochi_days"
    fun today(): String = LocalDate.now().toString()

    fun load(ctx: Context): List<Task> {
        val sp = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val raw = sp.getString("tasks", null)
        if (raw == null) {
            val seed = listOf(
                Task(1, "Drink water", Cat.DRINK, ""),
                Task(2, "Read 10 pages", Cat.READ, ""),
                Task(3, "Stretch", Cat.MOVE, "")
            )
            save(ctx, seed)
            return seed
        }
        val arr = JSONArray(raw)
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Task(o.getLong("id"), o.getString("title"),
                runCatching { Cat.valueOf(o.getString("cat")) }.getOrDefault(Cat.GENERAL),
                o.optString("lastDone", ""))
        }
    }

    fun save(ctx: Context, tasks: List<Task>) {
        val arr = JSONArray()
        tasks.forEach {
            arr.put(JSONObject().put("id", it.id).put("title", it.title)
                .put("cat", it.cat.name).put("lastDone", it.lastDone))
        }
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString("tasks", arr.toString()).apply()
    }

    fun toggle(ctx: Context, id: Long): List<Task> {
        val tasks = load(ctx).map {
            if (it.id != id) it else {
                val nowDone = !it.done
                bumpLog(ctx, if (nowDone) 1 else -1)
                it.copy(lastDone = if (nowDone) today() else "")
            }
        }
        save(ctx, tasks)
        return tasks
    }

    fun add(ctx: Context, title: String): List<Task> {
        val t = load(ctx) + Task(System.currentTimeMillis(), title.trim(), Detect.detect(title), "")
        save(ctx, t); return t
    }

    fun remove(ctx: Context, id: Long): List<Task> {
        val t = load(ctx).filter { it.id != id }
        save(ctx, t); return t
    }

    private fun bumpLog(ctx: Context, delta: Int) {
        val sp = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val log = JSONObject(sp.getString("log", "{}")!!)
        val k = today()
        log.put(k, maxOf(0, log.optInt(k, 0) + delta))
        sp.edit().putString("log", log.toString()).apply()
    }

    /** Completed counts for the last [n] days, oldest first. */
    fun lastDays(ctx: Context, n: Int = 7): List<Pair<LocalDate, Int>> {
        val log = JSONObject(ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString("log", "{}")!!)
        val today = LocalDate.now()
        return (n - 1 downTo 0).map { today.minusDays(it.toLong()).let { d -> d to log.optInt(d.toString(), 0) } }
    }

    fun streak(ctx: Context): Int {
        val log = JSONObject(ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString("log", "{}")!!)
        var d = LocalDate.now()
        if (log.optInt(d.toString(), 0) == 0) d = d.minusDays(1)   // today not done yet doesn't break the streak
        var s = 0
        while (log.optInt(d.toString(), 0) > 0) { s++; d = d.minusDays(1) }
        return s
    }
}
