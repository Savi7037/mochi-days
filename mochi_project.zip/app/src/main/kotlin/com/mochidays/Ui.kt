package com.mochidays

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathOperation
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.appwidget.updateAll
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.TextStyle as DayStyle
import java.util.Locale
import kotlin.math.PI
import kotlin.math.roundToInt
import kotlin.math.sin

object C {
    val bg1 = Color(0xFFF7FBFF); val bg2 = Color(0xFFDFEFFF)
    val primary = Color(0xFF3B9BF5); val deep = Color(0xFF1F6FD1)
    val ink = Color(0xFF1D3557); val sub = Color(0xFF6B84A3)
    val line = Color(0xFFD5E6F7)
}

private fun catColors(c: Cat): Pair<Color, Color> = when (c) {
    Cat.DRINK -> Color(0xFFDDF0FF) to Color(0xFF3B9BF5)
    Cat.EAT -> Color(0xFFFFEBD6) to Color(0xFFF59A3B)
    Cat.READ -> Color(0xFFE9E6FF) to Color(0xFF7B6CF0)
    Cat.MOVE -> Color(0xFFDDF7EE) to Color(0xFF2FBF91)
    Cat.SLEEP -> Color(0xFFE3E8FF) to Color(0xFF5568D6)
    Cat.CALM -> Color(0xFFDDF5F7) to Color(0xFF2AA6B4)
    Cat.CLEAN -> Color(0xFFE0F4FF) to Color(0xFF3DA8E0)
    Cat.GENERAL -> Color(0xFFE8EEF6) to Color(0xFF6B84A3)
}

private fun doing(c: Cat) = when (c) {
    Cat.DRINK -> "Mochi will sip some water"; Cat.EAT -> "Mochi will have a snack"
    Cat.READ -> "Mochi will read a book"; Cat.MOVE -> "Mochi will do some jumping jacks"
    Cat.SLEEP -> "Mochi will take a nap"; Cat.CALM -> "Mochi will meditate"
    Cat.CLEAN -> "Mochi will brush his teeth"; Cat.GENERAL -> "Mochi will do a happy dance"
}

// ------------------------------------------------------------------------------------
@Composable
fun MochiDaysApp() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current
    val density = LocalDensity.current
    val parts = remember { MochiParts(ctx) }
    val brain = remember { Brain(density.density).also { Fx.density = density.density } }

    var tasks by remember { mutableStateOf(Store.load(ctx)) }
    var streak by remember { mutableIntStateOf(Store.streak(ctx)) }
    var week by remember { mutableStateOf(Store.lastDays(ctx)) }
    var showAdd by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf<Task?>(null) }
    val bounds = remember { HashMap<Long, Rect>() }

    fun refresh(newTasks: List<Task>) {
        tasks = newTasks; streak = Store.streak(ctx); week = Store.lastDays(ctx)
        scope.launch { TasksWidget().updateAll(ctx) }
    }
    fun spot(id: Long): Offset? = bounds[id]?.let {
        Offset((it.right - brain.box - 10f * density.density).coerceAtLeast(0f),
            (it.top - brain.box * 0.97f + 12f * density.density).coerceAtLeast(brain.topInset))
    }
    LaunchedEffect(Unit) {
        delay(700)
        brain.greet(LocalTime.now().hour, tasks.count { it.done }, tasks.size)
    }

    val done = tasks.count { it.done }

    Box(Modifier.fillMaxSize().onSizeChanged { }) {
        SkyBackground()
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).statusBarsPadding()
                .padding(horizontal = 20.dp).padding(top = 12.dp, bottom = 120.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Header(parts, streak)
            ProgressCard(done, tasks.size)
            if (tasks.isEmpty()) {
                Text("No habits yet. Tap “New habit” and Mochi will act it out!", color = C.sub, fontSize = 15.sp,
                    modifier = Modifier.padding(vertical = 24.dp))
            }
            tasks.forEachIndexed { i, t ->
                TaskCard(
                    task = t, index = i,
                    onBounds = { bounds[t.id] = it },
                    onToggle = {
                        val nowDone = !t.done
                        refresh(Store.toggle(ctx, t.id))
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        val s = spot(t.id)
                        if (nowDone) {
                            val all = Store.load(ctx).all { it.done }
                            if (s != null) brain.performAt(t.cat, s.x, s.y, 2.6f, cheerAfter = true, line = if (all) "Everything done today!" else "Nice one!")
                            else brain.celebrate()
                            bounds[t.id]?.let { Fx.confetti(it.left + 40f * density.density, it.center.y, 26) }
                        } else brain.say("No worries, later!", 1.8f)
                    },
                    onPlay = {
                        val s = spot(t.id)
                        if (s != null) brain.performAt(t.cat, s.x, s.y, 5f, line = doing(t.cat))
                    },
                    onDelete = { deleting = t }
                )
            }
            WeekCard(week)
        }

        // add button + panel
        Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().navigationBarsPadding().imePadding()) {
            AnimatedVisibility(showAdd, enter = slideInVertically { it } + fadeIn(), exit = slideOutVertically { it } + fadeOut()) {
                AddPanel(
                    onClose = { showAdd = false },
                    onAdd = { title ->
                        showAdd = false
                        val updated = Store.add(ctx, title)
                        refresh(updated)
                        val t = updated.last()
                        scope.launch {
                            delay(450)
                            val s = spot(t.id)
                            if (s != null) brain.performAt(t.cat, s.x, s.y, 5f, line = doing(t.cat))
                        }
                    }
                )
            }
            if (!showAdd) {
                Box(Modifier.fillMaxWidth().padding(20.dp), contentAlignment = Alignment.BottomEnd) { NewHabitButton { showAdd = true } }
            }
        }

        MochiLayer(brain, parts)

        deleting?.let { t ->
            AlertDialog(
                onDismissRequest = { deleting = null },
                containerColor = Color.White,
                title = { Text("Remove “${t.title}”?", color = C.ink, fontWeight = FontWeight.SemiBold) },
                text = { Text("Mochi will miss it, but you can add it back anytime.", color = C.sub) },
                confirmButton = { TextButton(onClick = { refresh(Store.remove(ctx, t.id)); deleting = null }) { Text("Remove", color = Color(0xFFD64545)) } },
                dismissButton = { TextButton(onClick = { deleting = null }) { Text("Keep", color = C.deep) } }
            )
        }
    }
}

// ------------------------------------------------------------------------------------
@Composable
fun MochiLayer(brain: Brain, parts: MochiParts) {
    val d = LocalDensity.current
    val topInset = WindowInsets.statusBars.getTop(d).toFloat()
    val bottomInset = WindowInsets.navigationBars.getBottom(d).toFloat()
    val boxDp = 150.dp

    LaunchedEffect(Unit) {
        var last = 0L
        while (true) {
            withFrameNanos { n ->
                val dt = if (last == 0L) 0f else ((n - last) / 1_000_000_000f).coerceAtMost(0.05f)
                last = n
                brain.update(dt)
            }
        }
    }

    Box(Modifier.fillMaxSize().onSizeChanged { brain.setScreen(it.width.toFloat(), it.height.toFloat(), topInset + 8f, bottomInset + 90f * d.density) }) {
        // Mochi
        Box(
            Modifier
                .offset { IntOffset(brain.px.roundToInt(), brain.py.roundToInt()) }
                .size(boxDp)
                .pointerInput(Unit) {
                    detectTapGestures(onTap = { brain.tap() }, onDoubleTap = { brain.doubleTap() }, onLongPress = { brain.pet() })
                }
                .pointerInput(Unit) {
                    detectDragGestures(
                        onDragStart = { brain.dragStart() },
                        onDrag = { change, amount -> change.consume(); brain.dragBy(amount.x, amount.y) },
                        onDragEnd = { brain.dragEnd() },
                        onDragCancel = { brain.dragEnd() }
                    )
                }
        ) {
            Canvas(Modifier.fillMaxSize()) {
                @Suppress("UNUSED_VARIABLE") val f = brain.frame
                // soft ground shadow
                val sh = Color(0x22204060)
                drawOval(sh, Offset(size.width * 0.18f, size.height * 0.90f), Size(size.width * 0.64f, size.height * 0.07f))
                drawMochi(parts, brain.st, size.width)
            }
        }
        // particles and butterfly (never intercept touches)
        Canvas(Modifier.fillMaxSize()) {
            @Suppress("UNUSED_VARIABLE") val f = brain.frame
            Fx.draw(this)
            brain.butterflyPos()?.let { drawButterfly(it, brain.actT, density) }
        }
        // speech bubble
        val text = brain.bubble
        AnimatedVisibility(text != null, enter = fadeIn() + scaleIn(initialScale = 0.8f), exit = fadeOut(),
            modifier = Modifier.offset { IntOffset((brain.px + brain.box * 0.62f).roundToInt(), (brain.py - 6f * d.density).roundToInt()) }) {
            Box(Modifier.shadow(8.dp, RoundedCornerShape(16.dp)).background(Color.White, RoundedCornerShape(16.dp)).padding(horizontal = 12.dp, vertical = 8.dp)) {
                Text(text ?: "", color = C.ink, fontSize = 13.sp, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

private fun DrawScope.drawButterfly(c: Offset, t: Float, density: Float) {
    val flap = 0.35f + 0.65f * kotlin.math.abs(sin(t * 16f))
    val w = 13f * density; val h = 16f * density
    drawOval(Color(0xFFFF8FA3), Offset(c.x - w * flap, c.y - h), Size(w * flap, h))
    drawOval(Color(0xFFFF8FA3), Offset(c.x, c.y - h), Size(w * flap, h))
    drawOval(Color(0xFFB39DFF), Offset(c.x - w * 0.7f * flap, c.y - h * 0.1f), Size(w * 0.7f * flap, h * 0.8f))
    drawOval(Color(0xFFB39DFF), Offset(c.x, c.y - h * 0.1f), Size(w * 0.7f * flap, h * 0.8f))
    drawLine(C.ink, Offset(c.x, c.y - h * 0.9f), Offset(c.x, c.y + h * 0.5f), 2.2f * density)
}

// ------------------------------------------------------------------------------------
@Composable
fun SkyBackground() {
    val t = rememberInfiniteTransition(label = "sky")
    val a by t.animateFloat(0f, 1f, infiniteRepeatable(tween(26000, easing = LinearEasing)), label = "a")
    val b by t.animateFloat(0f, 1f, infiniteRepeatable(tween(38000, easing = LinearEasing)), label = "b")
    Canvas(Modifier.fillMaxSize()) {
        drawRect(Brush.verticalGradient(listOf(C.bg1, C.bg2)))
        fun cloud(cx: Float, cy: Float, s: Float, alpha: Float) {
            val col = Color.White.copy(alpha = alpha)
            drawCircle(col, s * 0.55f, Offset(cx, cy)); drawCircle(col, s * 0.75f, Offset(cx + s * 0.7f, cy - s * 0.2f))
            drawCircle(col, s * 0.55f, Offset(cx + s * 1.4f, cy)); drawRect(col, Offset(cx, cy), Size(s * 1.4f, s * 0.55f))
        }
        val w = size.width
        cloud(-200f + (w + 400f) * a, size.height * 0.16f, 46f * density, 0.65f)
        cloud(-300f + (w + 500f) * ((a + 0.55f) % 1f), size.height * 0.46f, 34f * density, 0.5f)
        cloud(-250f + (w + 450f) * b, size.height * 0.75f, 40f * density, 0.55f)
        drawCircle(Color(0x1A5EAEFF), size.width * 0.5f, Offset(size.width * 0.95f, -size.height * 0.02f))
    }
}

@Composable
fun Header(parts: MochiParts, streak: Int) {
    val today = LocalDate.now()
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(46.dp).clip(CircleShape).background(Brush.verticalGradient(listOf(Color(0xFF7CC0FF), Color(0xFF3B9BF5)))), contentAlignment = Alignment.Center) {
            Image(parts.head.img, null, Modifier.size(34.dp).offset(y = 2.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text("Mochi Days", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = C.ink, letterSpacing = (-0.3).sp)
            Text("${today.dayOfWeek.getDisplayName(DayStyle.FULL, Locale.getDefault())}, ${today.month.getDisplayName(DayStyle.SHORT, Locale.getDefault())} ${today.dayOfMonth}",
                fontSize = 13.sp, color = C.sub)
        }
        StreakChip(streak)
    }
}

@Composable
fun StreakChip(n: Int) {
    val t = rememberInfiniteTransition(label = "flame")
    val f by t.animateFloat(0.9f, 1.08f, infiniteRepeatable(tween(520, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "f")
    Row(Modifier.shadow(6.dp, RoundedCornerShape(50), ambientColor = Color(0x331F6FD1), spotColor = Color(0x331F6FD1))
        .background(Color.White, RoundedCornerShape(50)).padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Canvas(Modifier.size(18.dp)) {
            val w = size.width; val h = size.height
            val p = Path().apply {
                moveTo(w * 0.5f, 0f)
                cubicTo(w * 0.95f, h * 0.35f, w * 0.95f, h * 0.7f, w * 0.5f, h)
                cubicTo(w * 0.05f, h * 0.7f, w * 0.1f, h * 0.4f, w * 0.38f, h * 0.3f)
                cubicTo(w * 0.38f, h * 0.15f, w * 0.45f, h * 0.06f, w * 0.5f, 0f); close()
            }
            withTransform({ scale(f, f, Offset(w / 2f, h)) }) {
                drawPath(p, Brush.verticalGradient(listOf(Color(0xFFFFB347), Color(0xFFFF6B4A))))
                drawCircle(Color(0xFFFFE08A), w * 0.18f, Offset(w * 0.5f, h * 0.72f))
            }
        }
        Spacer(Modifier.width(6.dp))
        Text("$n", fontWeight = FontWeight.Bold, color = C.ink, fontSize = 15.sp)
    }
}

@Composable
fun ProgressCard(done: Int, total: Int) {
    val target = if (total == 0) 0f else done.toFloat() / total
    val p by animateFloatAsState(target, spring(dampingRatio = 0.75f, stiffness = 90f), label = "ring")
    val bump by animateFloatAsState(if (done == total && total > 0) 1.04f else 1f, spring(0.4f, 300f), label = "bump")
    Row(
        Modifier.fillMaxWidth().scale(bump).shadow(14.dp, RoundedCornerShape(26.dp), ambientColor = Color(0x331F6FD1), spotColor = Color(0x331F6FD1))
            .background(Brush.linearGradient(listOf(Color(0xFF4DA8FF), Color(0xFF2F86EA))), RoundedCornerShape(26.dp)).padding(20.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text("Today", color = Color.White.copy(alpha = 0.85f), fontSize = 14.sp)
            Text("$done of $total done", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
            Text(when { total == 0 -> "Add your first habit"; done == total -> "Perfect day!"; done == 0 -> "A gentle start is still a start"; else -> "Keep going, you're doing great" },
                color = Color.White.copy(alpha = 0.9f), fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
        }
        Box(Modifier.size(72.dp), contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize()) {
                val st = 9.dp.toPx()
                drawArc(Color.White.copy(alpha = 0.28f), 0f, 360f, false, Offset(st / 2, st / 2), Size(size.width - st, size.height - st), style = Stroke(st))
                drawArc(Color.White, -90f, 360f * p, false, Offset(st / 2, st / 2), Size(size.width - st, size.height - st), style = Stroke(st, cap = StrokeCap.Round))
            }
            Text("${(p * 100).roundToInt()}%", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }
    }
}

@Composable
fun TaskCard(task: Task, index: Int, onBounds: (Rect) -> Unit, onToggle: () -> Unit, onPlay: () -> Unit, onDelete: () -> Unit) {
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { delay(70L * index); shown = true }
    AnimatedVisibility(shown, enter = fadeIn(tween(350)) + slideInVertically(spring(0.8f, 200f)) { it / 2 } + scaleIn(initialScale = 0.94f)) {
        val (soft, strong) = catColors(task.cat)
        Row(
            Modifier.fillMaxWidth()
                .onGloballyPositioned { onBounds(it.boundsInRoot()) }
                .shadow(8.dp, RoundedCornerShape(22.dp), ambientColor = Color(0x261F6FD1), spotColor = Color(0x261F6FD1))
                .background(Color.White, RoundedCornerShape(22.dp))
                .clip(RoundedCornerShape(22.dp))
                .pointerInput(task.id) { detectTapGestures(onTap = { onPlay() }, onLongPress = { onDelete() }) }
                .padding(horizontal = 14.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            CheckCircle(task.done, strong, onToggle)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(task.title, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis,
                    color = if (task.done) C.sub else C.ink, textDecoration = if (task.done) TextDecoration.LineThrough else null)
                Text(task.cat.label, fontSize = 12.sp, color = strong, modifier = Modifier.padding(top = 2.dp))
            }
            Box(Modifier.size(44.dp).clip(RoundedCornerShape(14.dp)).background(soft), contentAlignment = Alignment.Center) {
                CatIcon(task.cat, strong, Modifier.size(24.dp))
            }
        }
    }
}

@Composable
fun CheckCircle(done: Boolean, color: Color, onClick: () -> Unit) {
    val prog by animateFloatAsState(if (done) 1f else 0f, tween(320, easing = FastOutSlowInEasing), label = "check")
    val pop by animateFloatAsState(if (done) 1f else 0.92f, spring(0.35f, 500f), label = "pop")
    Box(Modifier.size(34.dp).scale(pop).clickable(remember { MutableInteractionSource() }, null) { onClick() }, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val r = size.minDimension / 2f - 2.dp.toPx()
            drawCircle(color.copy(alpha = 0.18f + 0.0f), r, style = Stroke(2.2.dp.toPx()))
            drawCircle(color.copy(alpha = prog), r * prog.coerceAtLeast(0.01f))
            if (prog > 0.25f) {
                val a = ((prog - 0.25f) / 0.75f).coerceIn(0f, 1f)
                val p1 = Offset(size.width * 0.28f, size.height * 0.52f); val p2 = Offset(size.width * 0.44f, size.height * 0.67f); val p3 = Offset(size.width * 0.72f, size.height * 0.36f)
                val path = Path().apply {
                    moveTo(p1.x, p1.y)
                    if (a < 0.45f) lineTo(p1.x + (p2.x - p1.x) * (a / 0.45f), p1.y + (p2.y - p1.y) * (a / 0.45f))
                    else { lineTo(p2.x, p2.y); val k = (a - 0.45f) / 0.55f; lineTo(p2.x + (p3.x - p2.x) * k, p2.y + (p3.y - p2.y) * k) }
                }
                drawPath(path, Color.White, style = Stroke(3.2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
            }
        }
    }
}

@Composable
fun CatIcon(cat: Cat, color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width; val h = size.height
        val stroke = Stroke(w * 0.09f, cap = StrokeCap.Round, join = StrokeJoin.Round)
        when (cat) {
            Cat.DRINK -> {
                val p = Path().apply { moveTo(w * 0.5f, h * 0.06f); cubicTo(w * 0.95f, h * 0.55f, w * 0.85f, h * 0.95f, w * 0.5f, h * 0.95f)
                    cubicTo(w * 0.15f, h * 0.95f, w * 0.05f, h * 0.55f, w * 0.5f, h * 0.06f); close() }
                drawPath(p, color)
            }
            Cat.EAT -> {
                drawArc(color, 0f, 180f, true, Offset(w * 0.08f, h * 0.2f), Size(w * 0.84f, h * 0.7f))
                drawLine(color, Offset(w * 0.2f, h * 0.88f), Offset(w * 0.8f, h * 0.88f), w * 0.09f, StrokeCap.Round)
                drawLine(color, Offset(w * 0.7f, h * 0.06f), Offset(w * 0.52f, h * 0.38f), w * 0.07f, StrokeCap.Round)
            }
            Cat.READ -> {
                drawRoundRect(color, Offset(w * 0.06f, h * 0.18f), Size(w * 0.42f, h * 0.66f), androidx.compose.ui.geometry.CornerRadius(w * 0.08f))
                drawRoundRect(color.copy(alpha = 0.6f), Offset(w * 0.52f, h * 0.18f), Size(w * 0.42f, h * 0.66f), androidx.compose.ui.geometry.CornerRadius(w * 0.08f))
            }
            Cat.MOVE -> {
                val p = Path().apply { moveTo(w * 0.6f, h * 0.04f); lineTo(w * 0.2f, h * 0.55f); lineTo(w * 0.47f, h * 0.55f)
                    lineTo(w * 0.38f, h * 0.96f); lineTo(w * 0.8f, h * 0.4f); lineTo(w * 0.52f, h * 0.4f); close() }
                drawPath(p, color)
            }
            Cat.SLEEP -> {
                val a = Path().apply { addOval(Rect(w * 0.1f, h * 0.1f, w * 0.9f, h * 0.9f)) }
                val b = Path().apply { addOval(Rect(w * 0.34f, h * 0.0f, w * 1.0f, h * 0.66f)) }
                drawPath(Path.combine(PathOperation.Difference, a, b), color)
            }
            Cat.CALM -> {
                val p = Path().apply { moveTo(w * 0.5f, 0f); quadraticBezierTo(w * 0.58f, h * 0.42f, w, h * 0.5f)
                    quadraticBezierTo(w * 0.58f, h * 0.58f, w * 0.5f, h); quadraticBezierTo(w * 0.42f, h * 0.58f, 0f, h * 0.5f)
                    quadraticBezierTo(w * 0.42f, h * 0.42f, w * 0.5f, 0f); close() }
                drawPath(p, color)
            }
            Cat.CLEAN -> {
                drawCircle(color, w * 0.26f, Offset(w * 0.38f, h * 0.62f), style = stroke)
                drawCircle(color, w * 0.15f, Offset(w * 0.72f, h * 0.3f), style = stroke)
                drawCircle(color, w * 0.07f, Offset(w * 0.28f, h * 0.2f))
            }
            Cat.GENERAL -> {
                val p = Path().apply { moveTo(w * 0.18f, h * 0.55f); lineTo(w * 0.42f, h * 0.78f); lineTo(w * 0.84f, h * 0.26f) }
                drawPath(p, color, style = Stroke(w * 0.13f, cap = StrokeCap.Round, join = StrokeJoin.Round))
            }
        }
    }
}

@Composable
fun WeekCard(days: List<Pair<LocalDate, Int>>) {
    val maxV = (days.maxOfOrNull { it.second } ?: 0).coerceAtLeast(1)
    Column(
        Modifier.fillMaxWidth().shadow(8.dp, RoundedCornerShape(24.dp), ambientColor = Color(0x261F6FD1), spotColor = Color(0x261F6FD1))
            .background(Color.White, RoundedCornerShape(24.dp)).padding(18.dp)
    ) {
        Text("This week", fontWeight = FontWeight.SemiBold, fontSize = 16.sp, color = C.ink)
        Spacer(Modifier.height(14.dp))
        Row(Modifier.fillMaxWidth().height(96.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Bottom) {
            days.forEachIndexed { i, (date, n) ->
                val h by animateFloatAsState(0.1f + 0.9f * n / maxV, tween(600, delayMillis = 60 * i, easing = FastOutSlowInEasing), label = "bar$i")
                val isToday = date == LocalDate.now()
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom, modifier = Modifier.weight(1f).fillMaxHeight()) {
                    Box(Modifier.width(18.dp).fillMaxHeight(h * 0.78f).clip(RoundedCornerShape(9.dp))
                        .background(if (n == 0) C.line else if (isToday) C.primary else Color(0xFF9CCBFF)))
                    Spacer(Modifier.height(6.dp))
                    Text(date.dayOfWeek.getDisplayName(DayStyle.NARROW, Locale.getDefault()), fontSize = 11.sp,
                        color = if (isToday) C.deep else C.sub, fontWeight = if (isToday) FontWeight.Bold else FontWeight.Normal)
                }
            }
        }
    }
}

@Composable
fun NewHabitButton(onClick: () -> Unit) {
    val t = rememberInfiniteTransition(label = "fab")
    val s by t.animateFloat(1f, 1.05f, infiniteRepeatable(tween(1300, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "s")
    Row(
        Modifier.scale(s).shadow(14.dp, RoundedCornerShape(50), ambientColor = Color(0x551F6FD1), spotColor = Color(0x551F6FD1))
            .background(Brush.linearGradient(listOf(Color(0xFF4DA8FF), Color(0xFF2F86EA))), RoundedCornerShape(50))
            .clip(RoundedCornerShape(50)).clickable { onClick() }.padding(horizontal = 20.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("+", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.width(8.dp))
        Text("New habit", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun AddPanel(onClose: () -> Unit, onAdd: (String) -> Unit) {
    var text by remember { mutableStateOf("") }
    val cat = remember(text) { Detect.detect(text) }
    val (soft, strong) = catColors(cat)
    Column(
        Modifier.fillMaxWidth().shadow(24.dp, RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
            .background(Color.White, RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)).padding(20.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("New habit", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = C.ink, modifier = Modifier.weight(1f))
            TextButton(onClick = onClose) { Text("Cancel", color = C.sub) }
        }
        Spacer(Modifier.height(8.dp))
        TextField(
            value = text, onValueChange = { text = it.take(60) }, singleLine = true,
            placeholder = { Text("e.g. Drink water", color = C.sub) },
            shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth(),
            colors = TextFieldDefaults.colors(
                focusedContainerColor = Color(0xFFF1F7FF), unfocusedContainerColor = Color(0xFFF1F7FF),
                focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
                focusedTextColor = C.ink, unfocusedTextColor = C.ink, cursorColor = C.primary
            )
        )
        Spacer(Modifier.height(12.dp))
        Row(
            Modifier.clip(RoundedCornerShape(50)).background(soft).padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            CatIcon(cat, strong, Modifier.size(18.dp)); Spacer(Modifier.width(8.dp))
            Text(if (text.isBlank()) "Mochi acts out what you type" else doing(cat), color = strong, fontSize = 13.sp, fontWeight = FontWeight.Medium)
        }
        Spacer(Modifier.height(16.dp))
        Box(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp))
                .background(if (text.isBlank()) C.line else C.primary)
                .clickable(enabled = text.isNotBlank()) { onAdd(text) }.padding(vertical = 15.dp),
            contentAlignment = Alignment.Center
        ) { Text("Add habit", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 16.sp) }
    }
}
