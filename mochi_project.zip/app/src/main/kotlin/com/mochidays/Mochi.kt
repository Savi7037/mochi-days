package com.mochidays

import android.content.Context
import android.graphics.BitmapFactory
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import org.json.JSONObject
import kotlin.math.*
import kotlin.random.Random

/** The cut-out pieces of Mochi, loaded once. */
class MochiParts(ctx: Context) {
    class P(val img: ImageBitmap, val x: Float, val y: Float)
    val head: P; val torso: P; val armL: P; val armR: P; val legL: P; val legR: P

    init {
        val meta = JSONObject(ctx.assets.open("mochi/parts.json").bufferedReader().use { it.readText() })
        fun load(name: String): P {
            val bmp = ctx.assets.open("mochi/$name.png").use { BitmapFactory.decodeStream(it) }
            val m = meta.getJSONObject(name)
            return P(bmp.asImageBitmap(), m.getDouble("x").toFloat(), m.getDouble("y").toFloat())
        }
        head = load("head"); torso = load("torso")
        armL = load("arm_l"); armR = load("arm_r")
        legL = load("leg_l"); legR = load("leg_r")
    }
}

enum class Act {
    IDLE, WALK, DRINK, EAT, READ, MOVE, SLEEP, CALM, CLEAN,
    CHEER, SPIN, TUMBLE, SNEEZE, DANCE, BUTTERFLY, HELD, PET, SQUEAK
}

fun actFor(c: Cat): Act = when (c) {
    Cat.DRINK -> Act.DRINK; Cat.EAT -> Act.EAT; Cat.READ -> Act.READ; Cat.MOVE -> Act.MOVE
    Cat.SLEEP -> Act.SLEEP; Cat.CALM -> Act.CALM; Cat.CLEAN -> Act.CLEAN; Cat.GENERAL -> Act.DANCE
}

enum class Prop { NONE, CUP, MELON, BOOK, BRUSH }

/** Target values for one moment of an animation. Angles are degrees, clockwise on screen. */
class Pose {
    var dy = 0f; var rot = 0f; var sq = 1f
    var headRot = 0f; var headDy = 0f
    var armL = -72f; var armR = 72f
    var legL = 0f; var legR = 0f
    var mouth = 0f; var closed = false
    var front = false; var glasses = false; var prop = Prop.NONE
    var tilt = 0f // prop tilt
}

object Poses {
    private fun sin01(x: Float) = (sin(x) + 1f) / 2f

    fun of(act: Act, t: Float): Pose {
        val p = Pose()
        when (act) {
            Act.IDLE -> {
                p.dy = 3f * sin(t * 2f); p.rot = 1.2f * sin(t * 1.3f); p.sq = 1f + 0.012f * sin(t * 2f)
                p.headRot = 3f * sin(t * 0.9f)
                p.armL = -72f + 3f * sin(t * 1.7f); p.armR = 72f - 3f * sin(t * 1.5f)
            }
            Act.WALK -> {
                val w = t * 9f
                p.dy = -abs(sin(w)) * 9f; p.rot = 3.2f * sin(w); p.headRot = -2f * sin(w)
                p.legL = -max(0f, sin(w)) * 14f; p.legR = -max(0f, -sin(w)) * 14f
                p.armL = -72f + 13f * sin(w); p.armR = 72f + 13f * sin(w)
            }
            Act.DRINK -> {
                val s = sin01(t * 3f)
                p.front = true; p.prop = Prop.CUP
                p.armR = -150f - 6f * s; p.tilt = -18f - 22f * s
                p.headRot = -3f - 5f * s; p.mouth = 0.15f + 0.45f * s
                p.dy = 2f * sin(t * 2f)
            }
            Act.EAT -> {
                p.front = true; p.prop = Prop.MELON
                p.armR = -150f + 4f * sin(t * 9f); p.tilt = -20f
                p.mouth = 0.15f + 0.6f * abs(sin(t * 9f)); p.headRot = 2f * sin(t * 9f)
                p.dy = 2f * abs(sin(t * 9f))
            }
            Act.READ -> {
                p.prop = Prop.BOOK; p.glasses = true
                p.armL = -141f; p.armR = 141f
                p.headRot = 5f + 1.5f * sin(t * 1.5f); p.dy = 2f * sin(t * 1.6f)
                p.tilt = 2.5f * sin(t * 1.1f)
            }
            Act.MOVE -> {
                val j = abs(sin(t * 5f))
                p.dy = -j * 34f; p.sq = 1f + 0.05f * (1f - j)
                p.armL = -72f + (60f + 72f) * j; p.armR = 72f - (60f + 72f) * j
                p.legL = -j * 6f; p.legR = -j * 6f; p.mouth = 0.5f * j
            }
            Act.SLEEP -> {
                p.dy = 10f + 3f * sin(t * 1.3f); p.rot = 3f; p.headRot = 9f + 1.5f * sin(t * 1.3f)
                p.closed = true; p.sq = 1f - 0.015f * sin(t * 1.3f)
            }
            Act.CALM -> {
                p.dy = -10f - 9f * sin(t * 1.1f); p.closed = true
                p.armL = -141f; p.armR = 141f; p.headRot = 2f * sin(t * 0.8f)
                p.sq = 1f + 0.015f * sin(t * 1.1f)
            }
            Act.CLEAN -> {
                p.front = true; p.prop = Prop.BRUSH
                p.armL = 150f + 4f * sin(t * 14f); p.tilt = 8f * sin(t * 14f)
                p.mouth = 0.35f; p.headRot = 2f * sin(t * 14f)
            }
            Act.CHEER -> {
                val j = abs(sin(t * 6f))
                p.dy = -j * 26f; p.armL = 58f + 8f * sin(t * 12f); p.armR = -58f - 8f * sin(t * 12f)
                p.mouth = 0.8f; p.sq = 1f + 0.04f * (1f - j)
            }
            Act.SPIN -> { p.dy = -abs(sin(min(t, 1.1f) / 1.1f * PI.toFloat())) * 26f; p.mouth = 0.5f; p.armL = -30f; p.armR = 30f }
            Act.TUMBLE -> { p.dy = -sin(min(t, 1f) * PI.toFloat()) * 36f; p.armL = -110f; p.armR = 110f; p.mouth = 0.6f }
            Act.SNEEZE -> {
                if (t < 0.9f) { p.headRot = -10f * (t / 0.9f); p.mouth = 0.25f; p.dy = -2f * t; p.closed = t > 0.6f }
                else if (t < 1.4f) { p.headRot = 16f; p.mouth = 1f; p.closed = true; p.dy = 10f; p.sq = 0.95f }
                else { p.headRot = 4f; p.mouth = 0f }
            }
            Act.DANCE -> {
                val w = t * 7f
                p.dy = -abs(sin(w)) * 14f; p.rot = 7f * sin(w)
                p.armL = -72f + 140f * sin01(w); p.armR = 72f - 140f * sin01(w + PI.toFloat())
                p.legL = -max(0f, sin(w)) * 10f; p.legR = -max(0f, -sin(w)) * 10f
                p.headRot = 7f * sin(w); p.mouth = 0.5f
            }
            Act.BUTTERFLY -> {
                p.headRot = 8f * sin(t * 1.3f); p.armL = -118f + 10f * sin(t * 2f)
                p.mouth = 0.25f; p.dy = 2f * sin(t * 2f)
            }
            Act.HELD -> {
                p.dy = 0f; p.rot = 6f * sin(t * 9f)
                p.armL = -125f + 30f * sin(t * 12f); p.armR = 125f - 30f * sin(t * 12f + 1f)
                p.legL = 10f * sin(t * 11f); p.legR = -10f * sin(t * 11f); p.mouth = 0.55f; p.sq = 1.04f
            }
            Act.PET -> {
                p.closed = true; p.headRot = 5f * sin(t * 3f); p.dy = 2f * sin(t * 3f)
                p.sq = 1f - 0.02f * sin01(t * 3f); p.mouth = 0.1f
            }
            Act.SQUEAK -> {
                p.dy = -abs(sin(min(t, 0.6f) / 0.6f * PI.toFloat())) * 32f
                p.armL = -40f; p.armR = 40f; p.mouth = 0.7f
            }
        }
        return p
    }
}

/** Smoothly chases the target pose and drives blinking. */
class MochiState {
    var dy = 0f; var rot = 0f; var sq = 1f
    var headRot = 0f; var headDy = 0f
    var armL = -72f; var armR = 72f
    var legL = 0f; var legR = 0f
    var mouth = 0f; var closedAmt = 0f
    var front = false; var glasses = false; var prop = Prop.NONE; var tilt = 0f
    var flip = 1f; var extraRot = 0f
    private var blinkClock = 2f; private var blinkPhase = -1f

    val blink: Float
        get() {
            val auto = if (blinkPhase >= 0f) sin((blinkPhase / 0.16f) * PI.toFloat()).coerceIn(0f, 1f) else 0f
            return max(closedAmt, auto)
        }

    fun update(t: Pose, dt: Float) {
        val k = 1f - exp(-dt * 13f)
        dy += (t.dy - dy) * k; rot += (t.rot - rot) * k; sq += (t.sq - sq) * k
        headRot += (t.headRot - headRot) * k; headDy += (t.headDy - headDy) * k
        armL += (t.armL - armL) * k; armR += (t.armR - armR) * k
        legL += (t.legL - legL) * k; legR += (t.legR - legR) * k
        mouth += (t.mouth - mouth) * k
        closedAmt += ((if (t.closed) 1f else 0f) - closedAmt) * min(1f, k * 1.6f)
        tilt += (t.tilt - tilt) * k
        front = t.front; glasses = t.glasses; prop = t.prop
        blinkClock -= dt
        if (blinkPhase >= 0f) { blinkPhase += dt; if (blinkPhase > 0.16f) blinkPhase = -1f }
        else if (blinkClock <= 0f) { blinkPhase = 0f; blinkClock = 2f + Random.nextFloat() * 3.5f }
    }
}

private val FUR = Color(0xFFCF8E58)
private val INK = Color(0xFF3E1F0F)

private fun DrawScope.part(p: MochiParts.P, dx: Float = 0f, dy: Float = 0f) {
    val w = p.img.width; val h = p.img.height
    drawImage(
        p.img, IntOffset.Zero, IntSize(w, h),
        IntOffset((p.x + dx).roundToInt(), (p.y + dy).roundToInt()), IntSize(w, h),
        filterQuality = FilterQuality.Medium
    )
}

fun handPos(right: Boolean, deg: Float): Offset {
    val sh = if (right) G.SH_R else G.SH_L
    val hl = if (right) G.HAND_R else G.HAND_L
    val vx = hl.x - sh.x; val vy = hl.y - sh.y
    val r = Math.toRadians(deg.toDouble()); val c = cos(r).toFloat(); val s = sin(r).toFloat()
    return Offset(sh.x + vx * c - vy * s, sh.y + vx * s + vy * c)
}

/** Draws Mochi into a square box of [boxPx] pixels. */
fun DrawScope.drawMochi(parts: MochiParts, st: MochiState, boxPx: Float) {
    val s = boxPx / G.W
    withTransform({ scale(s, s, Offset.Zero); translate(-G.X0, -G.Y0) }) {
        withTransform({
            translate(0f, st.dy)
            rotate(st.rot + st.extraRot, G.FEET)
            scale(st.flip / st.sq, st.sq, G.FEET)
        }) {
            part(parts.legL, 0f, st.legL); part(parts.legR, 0f, st.legR)
            part(parts.torso)

            fun arms() {
                withTransform({ rotate(st.armL, G.SH_L) }) { part(parts.armL) }
                withTransform({ rotate(st.armR, G.SH_R) }) { part(parts.armR) }
            }
            if (!st.front) arms()

            withTransform({ translate(0f, st.headDy); rotate(st.headRot, G.NECK) }) {
                part(parts.head)
                val b = st.blink
                if (b > 0.03f) {
                    for (e in listOf(G.EYE_L, G.EYE_R)) {
                        val rx = G.EYE_RX; val ry = G.EYE_RY
                        drawOval(FUR, Offset(e.x - rx, e.y - ry), Size(rx * 2f, ry * 2f * min(1f, b * 1.05f)))
                        if (b > 0.8f) drawArc(INK, 20f, 140f, false, Offset(e.x - 24f, e.y - 14f), Size(48f, 28f), style = Stroke(5f))
                    }
                }
                if (st.mouth > 0.04f) {
                    val m = st.mouth.coerceAtMost(1f)
                    val w = G.MOUTH_W * (0.5f + 0.5f * m); val h = G.MOUTH_H * m
                    drawOval(Color(0xFF3E1D10), Offset(G.MOUTH.x - w / 2f, G.MOUTH.y - h * 0.2f), Size(w, h))
                    drawOval(Color(0xFFE88B8B), Offset(G.MOUTH.x - w * 0.28f, G.MOUTH.y + h * 0.35f), Size(w * 0.56f, h * 0.45f))
                }
                if (st.glasses) {
                    val c = Color(0xFF3A2A20)
                    for (e in listOf(G.EYE_L, G.EYE_R)) drawCircle(c, 46f, e, style = Stroke(6f))
                    drawLine(c, Offset(G.EYE_L.x + 44f, G.EYE_L.y), Offset(G.EYE_R.x - 44f, G.EYE_R.y), 6f)
                }
            }
            if (st.front) arms()

            when (st.prop) {
                Prop.CUP -> drawCup(handPos(true, st.armR), st.tilt)
                Prop.MELON -> drawMelon(handPos(true, st.armR), st.tilt)
                Prop.BOOK -> drawBook(Offset(515f, 612f + st.dy * 0f), st.tilt)
                Prop.BRUSH -> drawBrush(handPos(false, st.armL), st.tilt)
                Prop.NONE -> {}
            }
        }
    }
}

private fun DrawScope.drawCup(c: Offset, tilt: Float) = withTransform({ rotate(tilt, c) }) {
    val body = Path().apply {
        moveTo(c.x - 26f, c.y - 38f); lineTo(c.x + 26f, c.y - 38f)
        lineTo(c.x + 20f, c.y + 36f); lineTo(c.x - 20f, c.y + 36f); close()
    }
    val water = Path().apply {
        moveTo(c.x - 23f, c.y - 6f); lineTo(c.x + 23f, c.y - 6f)
        lineTo(c.x + 20f, c.y + 36f); lineTo(c.x - 20f, c.y + 36f); close()
    }
    drawPath(body, Color(0xE6E1F2FF)); drawPath(water, Color(0xFF60B8FF)); drawPath(body, INK, style = Stroke(4f))
}

private fun DrawScope.drawMelon(c: Offset, tilt: Float) = withTransform({ rotate(tilt, c) }) {
    drawArc(Color(0xFFF0565C), 0f, 180f, true, Offset(c.x - 40f, c.y - 40f), Size(80f, 80f))
    drawArc(Color(0xFF46A05A), 0f, 180f, false, Offset(c.x - 40f, c.y - 40f), Size(80f, 80f), style = Stroke(8f))
    drawArc(INK, 0f, 180f, true, Offset(c.x - 40f, c.y - 40f), Size(80f, 80f), style = Stroke(4f))
    for (dx in listOf(-18f, 0f, 18f)) drawOval(INK, Offset(c.x + dx - 3f, c.y + 8f), Size(6f, 9f))
}

private fun DrawScope.drawBook(c: Offset, tilt: Float) = withTransform({ rotate(tilt, c) }) {
    drawRoundRect(Color(0xFF508CE6), Offset(c.x - 78f, c.y - 50f), Size(156f, 100f), androidx.compose.ui.geometry.CornerRadius(10f))
    drawRect(Color.White, Offset(c.x - 70f, c.y - 42f), Size(67f, 84f)); drawRect(Color.White, Offset(c.x + 3f, c.y - 42f), Size(67f, 84f))
    for (i in 0..3) {
        drawLine(Color(0xFFAAC8EB), Offset(c.x - 60f, c.y - 26f + i * 16f), Offset(c.x - 14f, c.y - 26f + i * 16f), 3f)
        drawLine(Color(0xFFAAC8EB), Offset(c.x + 14f, c.y - 26f + i * 16f), Offset(c.x + 60f, c.y - 26f + i * 16f), 3f)
    }
    drawRoundRect(INK, Offset(c.x - 78f, c.y - 50f), Size(156f, 100f), androidx.compose.ui.geometry.CornerRadius(10f), style = Stroke(4f))
}

private fun DrawScope.drawBrush(c: Offset, tilt: Float) = withTransform({ rotate(tilt - 30f, c) }) {
    drawRoundRect(Color(0xFF7CC4FF), Offset(c.x - 8f, c.y - 44f), Size(16f, 78f), androidx.compose.ui.geometry.CornerRadius(8f))
    drawRect(Color.White, Offset(c.x - 11f, c.y - 58f), Size(22f, 18f))
    drawRect(INK, Offset(c.x - 11f, c.y - 58f), Size(22f, 18f), style = Stroke(3f))
}
