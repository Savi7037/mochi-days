package com.mochidays

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/** Mochi's mind: where he walks, what he does, and how he reacts to touches. */
class Brain(val density: Float) {
    private sealed class Step {
        class Go(val x: Float, val y: Float) : Step()
        class Do(val act: Act, val secs: Float) : Step()
    }

    val st = MochiState()
    var frame by mutableLongStateOf(0L)
    var px by mutableFloatStateOf(0f)
    var py by mutableFloatStateOf(0f)
    var bubble by mutableStateOf<String?>(null)
    var act = Act.IDLE; private set
    var actT = 0f; private set

    val box get() = 150f * density
    private val scale get() = box / G.W
    var screenW = 0f; var screenH = 0f; var topInset = 0f; var bottomInset = 0f

    private val q = ArrayDeque<Step>()
    private var cur: Step? = null
    private var curT = 0f
    private var held = false
    private var prevAct = Act.IDLE
    private var emitT = 0f
    private var bubbleT = 0f
    private var sneezed = false
    private var lastInteract = 0f
    private var clock = 0f

    fun setScreen(w: Float, h: Float, top: Float, bottom: Float) {
        val first = screenW == 0f
        screenW = w; screenH = h; topInset = top; bottomInset = bottom
        if (first) { px = w / 2f - box / 2f; py = h * 0.55f }
    }

    // ---- public reactions -------------------------------------------------------------
    fun say(text: String, secs: Float = 2.6f) { bubble = text; bubbleT = secs }

    fun greet(hour: Int, done: Int, total: Int) {
        val g = when { hour < 5 -> "Up late? Take it easy!"; hour < 12 -> "Good morning!"; hour < 18 -> "Good afternoon!"; else -> "Good evening!" }
        q.clear(); cur = null
        q.add(Step.Do(Act.CHEER, 1.6f))
        say(if (total > 0 && done == total) "All done today. I'm proud of you!" else g, 3.2f)
    }

    /** Walk next to a task card and act out its habit. (x, y) is the top-left of Mochi's box. */
    fun performAt(cat: Cat, x: Float, y: Float, secs: Float = 4.5f, cheerAfter: Boolean = false, line: String? = null) {
        q.clear(); cur = null; held = false
        q.add(Step.Go(x, y))
        q.add(Step.Do(actFor(cat), secs))
        if (cheerAfter) q.add(Step.Do(Act.CHEER, 1.8f))
        if (line != null) say(line, secs)
    }

    fun celebrate() { q.clear(); cur = null; q.add(Step.Do(Act.CHEER, 2.4f)); say("You did it! 🎉", 2.6f) }

    fun tap() { interact(); q.clear(); cur = null; q.add(Step.Do(Act.SQUEAK, 0.9f)); say(listOf("Squeak!", "Hi hi!", "Hehe", "Boop!", "Hello!").random(), 1.4f) }
    fun doubleTap() { interact(); q.clear(); cur = null; q.add(Step.Do(Act.SPIN, 1.2f)); say("Wheee!", 1.4f) }
    fun pet() { interact(); q.clear(); cur = null; q.add(Step.Do(Act.PET, 2.4f)); say("Mmm, nice...", 2.2f) }

    fun dragStart() { interact(); held = true; cur = null; q.clear(); say("Put me down! 😆", 1.6f) }
    fun dragBy(dx: Float, dy: Float) {
        px = (px + dx).coerceIn(-box * 0.3f, screenW - box * 0.7f)
        py = (py + dy).coerceIn(-box * 0.2f, screenH - box * 0.8f)
    }
    fun dragEnd() { held = false; q.add(Step.Do(Act.SQUEAK, 0.8f)) }

    fun butterflyPos(): Offset? =
        if (act != Act.BUTTERFLY) null
        else Offset(px + box * (0.5f + 0.75f * sin(actT * 1.3f)), py + box * (0.15f + 0.3f * sin(actT * 2.1f)))

    fun mouthXY() = Offset(px + (G.MOUTH.x - G.X0) * scale, py + (G.MOUTH.y - G.Y0 + st.dy) * scale)
    private fun headTop() = Offset(px + (G.NECK.x - G.X0 + 40f) * scale, py + (170f - G.Y0 + st.dy) * scale)
    fun center() = Offset(px + box / 2f, py + box / 2f)

    private fun interact() { lastInteract = clock }

    // ---- per-frame --------------------------------------------------------------------
    fun update(dt: Float) {
        frame++
        clock += dt
        if (bubbleT > 0f) { bubbleT -= dt; if (bubbleT <= 0f) bubble = null }

        if (held) { act = Act.HELD; actT += dt }
        else {
            if (cur == null) {
                cur = q.removeFirstOrNull() ?: run { planRandom(); q.removeFirstOrNull() }
                curT = 0f; actT = 0f
            }
            when (val c = cur) {
                is Step.Go -> {
                    act = Act.WALK; actT += dt; curT += dt
                    val dx = c.x - px; val dy = c.y - py
                    val d = hypot(dx, dy); val len = 190f * density * dt
                    if (d <= maxOf(len, 1f)) { px = c.x; py = c.y; cur = null }
                    else { px += dx / d * len; py += dy / d * len }
                }
                is Step.Do -> {
                    act = c.act; actT += dt; curT += dt
                    if (curT >= c.secs) cur = null
                }
                null -> {}
            }
        }

        if (act != prevAct) { onStart(act); prevAct = act }
        emit(dt)

        st.update(Poses.of(act, actT), dt)
        st.extraRot = if (act == Act.TUMBLE) { val p = min(actT / 1f, 1f); (p * p * (3f - 2f * p)) * 360f } else 0f
        st.flip = if (act == Act.SPIN) cos(min(actT / 1.1f, 1f) * 4f * PI.toFloat()) else 1f
        Fx.update(dt)
    }

    private fun onStart(a: Act) {
        sneezed = false; emitT = 0f
        val c = center()
        when (a) {
            Act.CHEER -> Fx.confetti(c.x, c.y - box * 0.2f, 36)
            Act.SQUEAK -> Fx.hearts(c.x, c.y - box * 0.3f, 4)
            Act.SPIN, Act.TUMBLE -> repeat(4) { Fx.sparkle(c.x + (Random.nextFloat() - 0.5f) * box, c.y + (Random.nextFloat() - 0.5f) * box) }
            else -> {}
        }
    }

    private fun emit(dt: Float) {
        emitT += dt
        val m = mouthXY(); val h = headTop()
        when (act) {
            Act.DRINK -> if (emitT > 0.45f) { emitT = 0f; Fx.drop(m.x + 10f * density, m.y, up = 120f) }
            Act.EAT -> if (emitT > 0.22f) { emitT = 0f; Fx.crumb(m.x, m.y + 6f * density) }
            Act.SLEEP -> if (emitT > 1.1f) { emitT = 0f; Fx.zzz(h.x, h.y) }
            Act.MOVE -> if (emitT > 0.28f) { emitT = 0f; Fx.drop(h.x - box * 0.35f, h.y + box * 0.2f, Color(0xFF9BD3FF), 90f) }
            Act.CALM -> if (emitT > 0.22f) { emitT = 0f; Fx.sparkle(center().x + (Random.nextFloat() - 0.5f) * box, center().y + (Random.nextFloat() - 0.5f) * box) }
            Act.CLEAN -> if (emitT > 0.16f) { emitT = 0f; Fx.bubble(m.x + (Random.nextFloat() - 0.5f) * 40f * density, m.y) }
            Act.DANCE -> if (emitT > 0.35f) { emitT = 0f; Fx.note(h.x + (Random.nextFloat() - 0.5f) * box, h.y) }
            Act.PET -> if (emitT > 0.2f) { emitT = 0f; Fx.hearts(h.x, h.y, 1) }
            Act.SNEEZE -> if (actT > 0.9f && !sneezed) {
                sneezed = true; say("ACHOO!", 1.3f); repeat(8) { Fx.drop(m.x, m.y, Color(0xFFBFE3FF), 220f) }
            }
            else -> {}
        }
    }

    private fun planRandom() {
        if (screenW <= 0f) { q.add(Step.Do(Act.IDLE, 1f)); return }
        // Mochi gets sleepy when you haven't touched him for a while
        if (clock - lastInteract > 40f && Random.nextInt(100) < 25) { goRandom(); q.add(Step.Do(Act.SLEEP, 7f)); lastInteract = clock - 20f; return }
        when (Random.nextInt(100)) {
            in 0..38 -> { goRandom(); if (Random.nextBoolean()) q.add(Step.Do(Act.IDLE, 1f + Random.nextFloat() * 2f)) }
            in 39..50 -> q.add(Step.Do(Act.SPIN, 1.2f))
            in 51..60 -> q.add(Step.Do(Act.TUMBLE, 1.3f))
            in 61..70 -> q.add(Step.Do(Act.DANCE, 3.2f))
            in 71..78 -> q.add(Step.Do(Act.SNEEZE, 2.4f))
            in 79..88 -> q.add(Step.Do(Act.BUTTERFLY, 4.5f))
            in 89..94 -> { goRandom(); q.add(Step.Do(Act.SLEEP, 6f)) }
            else -> q.add(Step.Do(Act.CHEER, 1.4f))
        }
    }

    private fun goRandom() {
        val x = Random.nextFloat() * (screenW - box)
        val minY = topInset + 8f * density
        val maxY = screenH - bottomInset - box * 0.95f
        q.add(Step.Go(x, minY + Random.nextFloat() * (maxY - minY).coerceAtLeast(1f)))
    }
}
